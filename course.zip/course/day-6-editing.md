# Purpose
This page teaches Day 6 of the AI Director Course: editing and assembly.
It exists to help learners combine generated clips and audio into one coherent, polished short video.
AI agents should keep this page tied to practical edit decisions rather than abstract theory alone.

# Maintenance Instructions
Update this page when recommended editing workflow, cut strategy, or finishing standards evolve.
Humans and AI agents may both refine it, but changes should stay accessible to beginners while remaining useful to experienced creators.
Keep the page centered on sequencing, pacing, and polish.

# Day 6 — The Assembly Line

## Outcome for Today
Assemble the final timeline, tighten the pacing, and establish one cohesive look.

## What You Need Before You Start
- your final visual clips
- your organized music, voice, and sound effects
- a clear shot order from the storyboard
- one editing tool you can move quickly in

## End-of-Day Deliverable
By the end of Day 6 you should have:
- a full near-final timeline
- clean pacing from hook to payoff
- one consistent finishing treatment across the sequence

## Fast Track
### Step 1 — Build the timeline in the simplest order possible
Import only approved assets first.
Do not clutter the timeline with every failed variation.

Build this order:
1. selected clips
2. voiceover if used
3. music bed
4. essential Foley and transitions

### Step 2 — Create the rough cut
Focus only on sequence logic.
Do not color grade or over-polish yet.

Ask:
- does the order make sense?
- does the energy build?
- is the final shot worth arriving at?

### Step 3 — Trim aggressively
Most AI clips are longer than they need to be.
Remove:
- unstable openings
- broken endings
- repetitive middles
- any frames that expose generation flaws

### Step 4 — Sync rhythm to the best available beat
Use whichever rhythm matters most:
- spoken cadence
- music downbeat
- visual action

Not every cut must hit the music, but the overall sequence should feel intentional.

### Step 5 — Apply the finishing pass
Use one simple global treatment to unify the sequence.
This can include:
- basic contrast and exposure correction
- subtle color shaping
- light sharpening only if needed
- text or title cleanup if included

## Edit Priorities
- clarity first
- pacing second
- style third

## Timeline Pass Order
Use this pass order to stay efficient:
1. story order pass
2. pacing pass
3. defect removal pass
4. audio balance pass
5. final polish pass

## Deep Dive
### What to cut first
Remove:
- awkward generation artifacts
- frames with unstable anatomy or product shape
- repetitive motion
- shots that do not move the story forward

### How to protect momentum
If a shot is beautiful but slows the piece down, shorten it.
If it still slows the piece down, remove it.

### How to use text overlays wisely
If you use text:
- keep it short
- place it where the frame is readable
- do not let it fight the main subject
- use it to clarify, not explain everything

### Color and consistency
A simple global treatment is often enough.
The goal is not to show off grading complexity but to make the sequence feel like one film.

### Audio finishing basics
- lower music under voice
- avoid hard audio cuts unless intentionally sharp
- let one or two moments breathe without crowding them
- prioritize clarity over loudness

## Troubleshooting
### Problem: the sequence feels slow
Remove the weakest shot first, then tighten the remaining clips.

### Problem: the edit feels flashy but unclear
Return to the Day 1 storyboard and restore the simplest visual logic.

### Problem: the music dictates too much
Re-edit the track or use only a smaller section.
The video should not feel trapped by the full song structure.

### Problem: the clips do not match visually
Apply a simple unified treatment and consider dropping the most visually inconsistent shot.

## Quality Checklist
Before moving to Day 7, confirm that your edit:
- reads clearly without explanation
- hides or removes the worst generation artifacts
- keeps music and voice in balance
- builds toward a strong payoff
- already feels close to publishable

## Mini Assignment
Export a rough review version and watch it once with sound and once muted.
Note what still feels unclear in each version.

### Common mistakes
- leaving too many clips in the timeline
- cutting before the viewer understands the shot
- failing to lower music under narration
- trying to save a broken clip that should be replaced instead

## Checkpoint
By the end of Day 6, you should have a complete rough-to-near-final edit that already feels publishable.

## Save for Tomorrow
Carry these into Day 7:
- your near-final timeline
- a short list of remaining fixes
- the original Day 1 blueprint for comparison

## Tomorrow
Day 7 is for critique, upscale, export, and final polish.
