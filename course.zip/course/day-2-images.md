# Purpose
This page teaches Day 2 of the AI Director Course: converting storyboard shots into strong static frames.
It exists to help learners establish visual quality and consistency before adding motion.
AI agents should keep this page consistent with Day 1 storyboard structure and Day 3 motion needs.

# Maintenance Instructions
Update this page when the image-generation workflow, prompt formula, or consistency techniques change.
Humans and AI agents may both refine it, but the page should stay tool-agnostic wherever possible.
Keep the guidance grounded in repeatable prompt construction and consistency discipline.

# Day 2 — Mastering the Frame

## Outcome for Today
Generate one strong keyframe for each planned shot while preserving subject and style consistency.

## What You Need Before You Start
- your approved Day 1 storyboard
- one fixed subject description
- three style anchors you do not want to change
- a folder structure for saving image variants and final selects

## End-of-Day Deliverable
By the end of Day 2 you should have:
- one approved keyframe for each shot
- a stable subject description
- a repeatable prompt formula
- notes on what visual details must be preserved in Day 3 motion generation

## Fast Track
### Step 1 — Build your master visual identity block
Before writing shot-specific prompts, lock the constants.

Create one reusable identity block containing:
- subject description
- wardrobe or product details
- visual style anchors
- color palette hints
- quality intent

Example:

```text
Premium stainless-steel espresso machine with clean geometric lines, brushed metal finish, matte black accents, cinematic realism, moody morning light, premium lifestyle aesthetic, shallow depth of field, polished product photography quality.
```

### Step 2 — Translate each shot into a prompt
Use your Day 1 storyboard and convert each shot into a prompt that mixes fixed identity details with shot-specific changes.

Keep these stable across all shots unless the storyboard requires a real change:
- subject identity
- style language
- environment family
- lighting world

### Step 3 — Generate multiple variants per shot
For each shot, create several variations before choosing a winner.
Do not lock onto the first acceptable image.

What to vary carefully:
- framing
- pose or action intensity
- amount of background detail
- contrast or mood strength

What not to vary casually:
- subject identity
- product shape
- core style language

### Step 4 — Compare shots together, not in isolation
An image can be strong on its own and still fail the sequence.

Review your selected images side by side and ask:
- Do these feel like the same world?
- Does the subject remain recognizable?
- Is the visual escalation working from shot 1 to shot 5?

### Step 5 — Save finals and note continuity locks
For each final frame, record:
- exact prompt used
- any reference image or setting used
- what worked
- what broke
- what must stay fixed in later generations

## Cinematic Prompt Formula
Use this structure for each shot:

```text
[subject] + [action or pose] + [environment] + [camera framing] + [lighting] + [visual style] + [quality cues]
```

## Prompt Builder Template
Use this fuller template when turning a storyboard shot into a keyframe prompt:

```text
[fixed subject identity],
[shot-specific action or pose],
[environment details],
[camera framing],
[lighting intent],
[style anchors],
[texture or realism cues],
[quality cues]
```

## Example Prompt Breakdown
### Base identity block

```text
Premium stainless-steel espresso machine, brushed metal finish, matte black details, calm luxury aesthetic, cinematic realism.
```

### Shot-specific layer

```text
Close-up of espresso pouring into a ceramic cup on a stone kitchen counter, soft dawn window light, shallow depth of field, warm steam visible, product photography framing, polished reflections, highly detailed, clean premium composition.
```

### Combined prompt

```text
Premium stainless-steel espresso machine, brushed metal finish, matte black details, calm luxury aesthetic, cinematic realism, close-up of espresso pouring into a ceramic cup on a stone kitchen counter, soft dawn window light, shallow depth of field, warm steam visible, product photography framing, polished reflections, highly detailed, clean premium composition.
```

## Consistency Rules
- Keep the subject description nearly identical across all related shots.
- Reuse the same visual style language throughout the sequence.
- Track wardrobe, props, colors, and background logic.
- Use reference features such as `CREF` or `SREF` when your chosen tool supports them.

## `CREF` and `SREF` in Plain Language
Different tools use different names, but the ideas are consistent:

- `CREF` helps preserve character or subject identity across shots.
- `SREF` helps preserve style across shots.

Use them when:
- the same person must stay recognizable
- the same product must keep its design details
- the same visual language must survive prompt changes

Do not assume references fix everything.
You still need disciplined prompts and careful selection.

## Practical Consistency Workflow
1. Get one excellent anchor image first.
2. Reuse that image as a reference where your tool allows it.
3. Keep the identity block stable.
4. Change only the shot-specific layer.
5. Reject outputs that drift, even if they look impressive.

## Deep Dive
### Why static frames come before motion
If the keyframe is weak, motion usually amplifies the weakness.
A strong still image gives you a visual contract that later motion tools should preserve.

### Why most image inconsistency starts on Day 2
If you improvise the prompt from scratch for every shot, the model starts treating every frame like a new scene.
That creates character drift, product redesign, and style collapse.

Day 2 is where sequence discipline begins.

### What to evaluate
- Facial or product consistency
- Lighting continuity
- Composition strength
- Shot-to-shot escalation
- Absence of obvious model errors

### What makes a frame usable for Day 3
Choose frames with:
- clear silhouette
- clean edges
- readable focal point
- believable anatomy or product geometry
- lighting that can survive small amounts of motion

Avoid frames with:
- tangled fingers or warped surfaces
- busy backgrounds that compete with the subject
- inconsistent reflections or impossible materials
- ambiguous camera angle that weakens the shot's purpose

## Troubleshooting
### Problem: the character or product keeps changing
Shorten the variable part of the prompt and strengthen the fixed identity block.
If available, anchor from a reference image instead of relying on text alone.

### Problem: the style feels random from shot to shot
Write three to five style anchors and copy them unchanged into every prompt.

### Problem: the image is pretty but not useful
Judge the frame against the storyboard role.
If a shot is meant to reveal detail, choose clarity over spectacle.

### Problem: every image looks overdesigned
Reduce style adjectives and focus on subject, framing, and light.
Too much decorative prompting often creates generic gloss instead of cinematic control.

### Problem: you cannot pick a final frame
Choose the image that best supports the full sequence, not the image that looks most flashy on its own.

## Quality Checklist
Before moving to Day 3, confirm that each selected frame:
- matches the Day 1 storyboard role
- preserves the same subject identity
- fits the same style world
- has a clear focal point
- avoids defects that motion would exaggerate

## Mini Assignment
For one of your five shots, create:
- one version optimized for realism
- one version optimized for style

Compare them and decide which better serves the final video goal.

### Common mistakes
- Rewriting the character from scratch for every prompt
- Changing style language between shots
- Accepting an image with small defects that will become larger in video

## Checkpoint
By the end of Day 2, you should have a clean ordered set of static frames that could already function as a storyboard animatic.

## Save for Tomorrow
Carry these into Day 3:
- your final selected frames
- the winning prompt for each frame
- the reference image strategy you used
- notes on which images feel safest for motion

## Tomorrow
Day 3 uses these frames as the launch point for controlled motion.
