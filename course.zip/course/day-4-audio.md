# Purpose
This page teaches Day 4 of the AI Director Course: voice, dialogue, and lip sync.
It exists to help learners add spoken content only when it improves clarity, persuasion, or emotional impact.
AI agents should keep this page aligned with the broader principle that audio should support the visuals rather than overcomplicate them.

# Maintenance Instructions
Update this page when voice-generation options, lip-sync guidance, or dialogue-writing standards evolve.
Humans and AI agents may both refine it, but changes should preserve a practical, results-first approach.
Keep the guidance short enough for execution and clear enough for troubleshooting.

# Day 4 — The Spoken Word

## Outcome for Today
Generate a clean voice track and sync it to your visuals if dialogue or narration improves the piece.

## What You Need Before You Start
- your approved Day 3 clip sequence
- a decision on whether speech is necessary
- a short message, script, or call to action
- a quiet review process for listening critically

## End-of-Day Deliverable
By the end of Day 4 you should have:
- a final voice track or a documented decision to skip speech
- a short approved script
- any lip-synced clips that are genuinely worth keeping

## Fast Track
### Step 1 — Decide whether speech helps or harms
Ask one question first:

```text
Would the video become clearer, more persuasive, or more emotional with a voice track?
```

If the answer is no, skip speech and move to Day 5 with confidence.

### Step 2 — Write a short script
Write one line at a time.
Aim for clarity over cleverness.

Use this structure when needed:
- line 1: hook or emotional setup
- line 2: benefit, transformation, or key message
- line 3: call to action or closing image support

### Step 3 — Generate several readings
Test variations in:
- pace
- warmth
- authority
- energy level

Keep the script fixed while comparing voices.

### Step 4 — Select the best voice take
Choose the take that fits the visual tone and leaves room for music.
Natural pacing matters more than novelty.

### Step 5 — Add lip sync only where it earns its place
Use lip sync only when:
- the mouth is visible enough to matter
- the shot is stable enough to support it
- the speech materially improves the scene

## Script Rule
If one sentence can do the job, do not write three.

## Script Template
Use this when writing short voiceover:

```text
Hook:
Core message:
Closing line:
```

## Example Script Patterns
### Product ad

```text
Start your morning with something that feels intentional.
Precision design, rich flavor, and a ritual worth slowing down for.
Make every cup feel cinematic.
```

### Portfolio mood piece

```text
Some moments do not need volume to feel powerful.
They just need rhythm, light, and control.
```

## Deep Dive
### When to avoid dialogue
Skip spoken audio when:
- the visuals already tell the story
- text overlays can carry the message better
- imperfect lip sync would distract from the final result

### Voiceover vs on-screen dialogue
- **Voiceover** is safer and easier to control.
- **On-screen dialogue** is higher risk because lip sync and facial fidelity must hold up.

If you are unsure, choose voiceover.

### What makes good generated narration
- clear pacing
- natural pauses
- believable emphasis
- emotional match with the visual tone

### What makes lip sync believable enough
- the shot is not too wide
- the face stays stable
- the line is short
- the lighting does not hide or distort the mouth
- the timing feels natural rather than robotic

### Where to place speech in the timeline
The strongest placement is often:
- after the opening visual hook
- during the clearest explanatory shot
- before the final payoff or call to action

Do not force words over every scene.

## Troubleshooting
### Problem: the voice sounds artificial
Try a simpler script, slower pacing, or a more neutral voice.
Overwritten copy often sounds more robotic than plain language.

### Problem: the lip sync looks distracting
Use voiceover instead.
Do not keep visible lip sync just because it was technically possible.

### Problem: the narration fights the music
Choose a calmer voice take or leave more silence in the track.
Day 5 will work better if the voice has room to breathe.

### Problem: the script feels too long
Cut every sentence that repeats what the visuals already show.

## Quality Checklist
Before moving to Day 5, confirm that your spoken layer:
- adds value rather than clutter
- matches the visual tone
- is short enough to remain memorable
- avoids lip-sync shots that weaken the project

## Mini Assignment
Record two script versions for the same project:
- one with voiceover
- one with no voice, only planned text overlay

Decide which version makes the piece feel more premium.

### Common mistakes
- forcing dialogue into every project
- choosing an overly dramatic voice for a simple product ad
- syncing speech on wide shots where it adds no value

## Checkpoint
By the end of Day 4, any spoken content should feel intentional, concise, and supportive of the visuals.

## Save for Tomorrow
Carry these into Day 5:
- final voiceover export if used
- notes on where silence should remain
- any moments that need musical lift or Foley support

## Tomorrow
Day 5 adds music and sound design to create atmosphere and momentum.
