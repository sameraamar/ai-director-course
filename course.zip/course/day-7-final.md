# Purpose
This page teaches Day 7 of the AI Director Course: final review and polish.
It exists to help learners evaluate their work against the original blueprint, improve the final presentation, and export a strong finished piece.
AI agents should preserve the connection between Day 1 intent and Day 7 evaluation when refining this page.

# Maintenance Instructions
Update this page when export guidance, self-critique framework, or finishing workflow changes.
Humans and AI agents may both refine it, but the page should remain focused on practical completion and honest review.
Keep the guidance grounded in final quality, not endless tweaking.

# Day 7 — The Premiere

## Outcome for Today
Export a polished final video and evaluate it against the original vision.

## What You Need Before You Start
- your near-final Day 6 edit
- the Day 1 storyboard and project goal
- a checklist for export versions
- enough distance to judge the piece honestly

## End-of-Day Deliverable
By the end of Day 7 you should have:
- one final master export
- one delivery export sized for its target platform
- a short self-review of what worked and what to improve next time

## Fast Track
### Step 1 — Review without touching the timeline
Watch the piece from start to finish once as a viewer, not an editor.
Take notes only.

### Step 2 — Compare against the blueprint
Check the finished piece against:
- Day 1 concept sentence
- Day 1 payoff shot intention
- the audience or business goal

### Step 3 — Make only high-value final fixes
Prioritize changes that clearly improve:
- clarity
- opening hook
- ending strength
- sound smoothness
- overall polish

### Step 4 — Improve resolution only after the edit is final
Upscale, sharpen, or export at higher resolution only when the content itself is already approved.

### Step 5 — Export deliberately
Create at least:
- one master export
- one version sized for the primary platform
- one backup archive of key assets and prompts

## Final Review Questions
- Does the story read clearly?
- Does the visual style stay consistent?
- Is the pacing strong from first shot to last shot?
- Does the sound increase the cinematic illusion?
- Would you feel confident publishing this today?

## Export Checklist
- correct aspect ratio
- clean audio levels
- no missing clips or black frames
- no accidental placeholder text
- file naming that matches the project

## Deep Dive
### The self-critique rule
Judge the work against the brief you set on Day 1, not against every possible film on the internet.

### What counts as a successful sprint result
A successful result is not perfect.
It is a finished short video that:
- matches the intended goal
- demonstrates control over sequence and style
- is strong enough to publish or show

### How to decide whether to keep polishing
Ask whether the next change will make the piece meaningfully better for the viewer.
If not, stop.

### High-value last-mile fixes
- tighten the opening seconds
- improve the ending frame
- smooth harsh audio transitions
- remove a visibly weak shot
- simplify overdone effects

### Archive what matters
Save:
- final exports
- project file if available
- prompts
- selected keyframes
- audio assets
- notes on what worked best

That archive becomes your speed advantage on the next project.

## Troubleshooting
### Problem: the piece still feels unfinished
Identify whether the problem is clarity, pacing, or polish.
Do not solve all three at once.

### Problem: upscaling makes artifacts worse
Use the cleaner base export instead of forcing artificial sharpness.

### Problem: the final shot does not land
Replace it with the stronger alternate or shorten the lead-in so the ending arrives with more impact.

### Problem: you cannot stop tweaking
Set a final review pass limit and publish the best honest version.

## Quality Checklist
Before declaring the sprint complete, confirm that:
- the final file is export-ready
- the message or mood is clear
- the ending feels intentional
- the sound supports the visuals
- the project is archived for reuse

## Mini Assignment
Write a three-line postmortem:
- what worked best
- what failed most often
- what you will change in the next sprint

### Common mistakes
- endless tweaking with no clear improvement
- exporting one low-quality version only
- forgetting to archive project assets and prompts

## Finish Line
You now have a complete AI-directed video project and a repeatable workflow you can use again with better speed and taste.

## Next Iteration
Repeat the sprint with:
- a new product
- a stronger visual style target
- tighter shot discipline
- better sound layering
