# Purpose
This page teaches Day 3 of the AI Director Course: turning still frames into motion.
It exists to help learners add believable camera movement and subject motion without losing the visual quality created on Day 2.
AI agents should expand this page with practical motion-prompt patterns and artifact-mitigation guidance as the curriculum matures.

# Maintenance Instructions
Update this page when the image-to-video workflow, motion prompt library, or troubleshooting patterns improve.
Humans and AI agents may both refine it, but changes should stay consistent with Day 2 frame preparation and Day 6 editing needs.
Keep the guidance focused on controllable motion and common failure recovery.

# Day 3 — Breathing Life

## Outcome for Today
Create short video clips from your keyframes using deliberate motion instead of random animation.

## What You Need Before You Start
- your final Day 2 keyframes
- the winning prompt for each keyframe
- notes on what details must not drift
- enough storage to save multiple clip attempts per shot

## End-of-Day Deliverable
By the end of Day 3 you should have:
- one usable moving clip for each storyboard shot
- a short note describing the motion goal of each clip
- a list of shots that may need replacement or cleanup during editing

## Fast Track
### Step 1 — Define the motion role of each shot
Before generating anything, decide what motion is supposed to achieve.

Use one of these roles for each shot:
- **Reveal:** introduces the subject or environment
- **Emphasis:** draws attention to a feature or detail
- **Transition:** bridges one visual idea to the next
- **Escalation:** increases emotion, intensity, or scale
- **Hold:** keeps the shot mostly stable while preserving atmosphere

### Step 2 — Separate camera motion from subject motion
Treat these as different systems.

- **Camera motion:** pan, tilt, dolly, push-in, orbit, pull-back
- **Subject motion:** hand movement, steam rising, fabric shifting, head turn, liquid pouring

Start with one dominant camera move and minimal subject motion.

### Step 3 — Keep clips short and useful
Shorter clips are usually easier to control.

For each shot:
1. generate a short version first
2. check for drift and deformation
3. only extend motion if the short version stays stable

### Step 4 — Generate multiple motion options
For each shot, try small variations of the same motion idea rather than reinventing the shot.

Good variation examples:
- same push-in, different intensity
- same pan, slightly different speed
- same locked shot, more or less secondary motion

### Step 5 — Approve only edit-ready clips
Keep the clips that:
- preserve the Day 2 frame quality
- support the storyboard role
- avoid obvious warping
- give Day 6 enough usable frames to cut around defects

## Motion Prompt Starters
- Slow dolly in toward the subject while keeping the background stable
- Gentle left-to-right pan with cinematic parallax
- Subtle tilt upward to reveal scale
- Locked composition with natural secondary motion only
- Slow push-in on product detail with controlled highlights

## Motion Prompt Template
Use this structure for controlled image-to-video prompting:

```text
[primary camera motion], [secondary motion if needed], keep [subject or product] stable, preserve [identity details], maintain [lighting and style], natural cinematic movement, no distortion, no warping.
```

## Example Motion Prompts
### Product reveal

```text
Slow dolly in toward the espresso machine, keep the product centered and stable, soft steam rising naturally, preserve brushed metal details, maintain moody dawn lighting, cinematic movement, no distortion, no product morphing.
```

### Atmospheric hold

```text
Locked composition with subtle natural steam movement and gentle light flicker, keep the cup and machine stable, preserve reflections and premium product detail, calm cinematic realism, no warping.
```

### Scale reveal

```text
Subtle tilt upward to reveal the full kitchen environment, keep the machine shape consistent, maintain warm morning light and clean premium styling, smooth camera motion, no background collapse.
```

## Camera Movement Library
### Use these when you want control
- **Push-in / dolly in:** adds focus and importance
- **Pull-back:** creates context or calm
- **Pan:** reveals width or guides the eye
- **Tilt:** reveals height or scale
- **Locked shot with secondary motion:** safest option when the frame is already strong

### Use carefully
- **Orbit moves:** can look impressive but often introduce geometry drift
- **Aggressive handheld motion:** may add energy but can amplify model instability
- **Fast combined moves:** usually too unstable for short AI clips

## Deep Dive
### Best practice for motion prompts
Prompt one dominant idea first.
Too many simultaneous instructions often cause unstable motion.

### Think in physics, not just aesthetics
The best motion prompts respect what should logically move.

Examples:
- steam can drift and curl
- fabric can sway slightly
- liquid can pour
- a camera can push in slowly
- a heavy product should not wobble like rubber

If the intended motion violates the material logic of the scene, the output usually looks fake.

### Match movement type to shot purpose
- **Hero or product shot:** prioritize stability
- **Transition shot:** allow a little more motion energy
- **Detail shot:** use small controlled movement to protect detail
- **Mood shot:** let atmospheric secondary motion do most of the work

### Safe clip selection strategy
Choose clips with a usable middle, not just a strong first second.
The first few frames can look good while the end of the clip collapses.

When reviewing, check:
- beginning stability
- middle-frame consistency
- ending drift
- editability if trimmed shorter

### Common artifact risks
- melting faces
- drifting hands
- morphing products
- unstable edges
- background geometry collapse

### Common causes of failure
- source image too busy or already flawed
- motion prompt asks for too many things at once
- clip duration is longer than the shot needs
- camera and subject both move aggressively
- lighting reflections change in impossible ways

### Recovery tactics
- shorten the clip duration
- reduce motion intensity
- choose a cleaner source image
- simplify the prompt to one camera move
- regenerate only the failed shot instead of the full sequence

## Troubleshooting
### Problem: the product changes shape during motion
Reduce subject motion and use a more stable camera move.
If needed, pick a cleaner Day 2 frame with simpler reflections.

### Problem: the face melts or drifts
Choose a tighter source image with cleaner facial structure.
Use smaller movements and shorter clip duration.

### Problem: the background bends unnaturally
Reduce motion complexity.
A locked or lightly panning shot is often more believable than an ambitious orbit.

### Problem: the clip starts well then breaks
Trim the shot shorter if the usable section is long enough.
If not, regenerate with lower intensity.

### Problem: every shot feels too static
Add one small element of secondary motion instead of forcing a large camera move.
Steam, light flicker, cloth motion, or environmental movement often adds enough life.

## Quality Checklist
Before moving to Day 4, confirm that each approved clip:
- preserves the Day 2 subject identity
- fits the storyboard role
- contains usable frames beyond the opening moment
- avoids obvious geometry collapse
- can be edited cleanly with your other shots

## Mini Assignment
Take one keyframe and generate:
- one version with a camera push-in
- one version with a locked camera and secondary motion only

Compare which one better preserves realism and supports the sequence.

## Checkpoint
By the end of Day 3, you should have a rough moving version of your entire sequence.

## Save for Tomorrow
Carry these into Day 4:
- the final approved clips
- notes on which shots can hide voiceover well
- any clips where visible speaking would be risky or distracting

## Tomorrow
Day 4 adds voice, dialogue, or lip sync only if the concept needs it.
