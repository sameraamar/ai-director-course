# Purpose
This page teaches Day 1 of the AI Director Course: building the director's blueprint.
It exists to help learners convert a vague idea into a concrete sequence of shots that later AI tools can execute consistently.
AI agents should keep this page aligned with the sprint promise and use it as the foundation for downstream lesson pages.

# Maintenance Instructions
Update this page when the Day 1 framework, storyboard prompt patterns, or troubleshooting guidance changes.
Humans and AI agents may both refine it, but it should remain clearly connected to Days 2 through 7.
Keep examples short, practical, and focused on output quality.

# Day 1 — The Director's Blueprint

## Outcome for Today
Create a 5-shot storyboard that defines subject, action, camera language, and lighting intent.

## What You Need Before You Start
- One simple concept that can be shown clearly in under 60 seconds
- A rough goal for the video: product ad, brand teaser, or portfolio piece
- One place to save notes, prompts, and asset decisions

## End-of-Day Deliverable
By the end of Day 1 you should have:
- a single-sentence concept
- a clear audience or viewer intent
- a 5-shot sequence
- continuity notes that will carry into image generation on Day 2

## Fast Track
### Step 1 — Lock the concept in one sentence
Choose one idea that can survive simplification.

Use this sentence structure:

```text
This video shows [subject] moving through [situation] to create [emotion or outcome] for [audience].
```

Example:

```text
This video shows a premium coffee grinder in a moody morning kitchen to create a calm luxury feeling for design-conscious home baristas.
```

### Step 2 — Decide the job of the video
Pick one primary goal:
- sell a product
- reveal a brand mood
- show off a cinematic idea

If you try to do all three equally, the storyboard usually becomes vague.

### Step 3 — Choose the 5-shot arc
Use this simple structure:
1. **Hook** — introduce the subject fast
2. **Context** — show the world or problem
3. **Detail** — highlight the most interesting feature
4. **Escalation** — add energy, motion, or emotional weight
5. **Payoff** — land the final image or message

### Step 4 — Fill in each shot card
For every shot, define:
- subject
- action
- camera framing
- lighting mood
- environment
- continuity notes

Copy this template five times:

```text
Shot number:
Shot purpose:
Subject:
Action:
Camera framing:
Lighting intent:
Environment:
Continuity notes:
```

### Step 5 — Pressure-test the sequence
Ask:
- Can a stranger understand the sequence?
- Does each shot have a different job?
- Is the final shot stronger than the first?
- Would this still work if the final video ends up closer to 30 seconds than 60?

### Step 6 — Save the blueprint cleanly
Store the following in one document:
- final concept sentence
- 5-shot storyboard
- style adjectives
- non-negotiable continuity notes
- ideas to avoid

## Prompt Skeleton
Use this as a starting structure with your preferred planning assistant:

```text
You are a cinematic storyboard assistant.
Turn this concept into a 5-shot sequence for a 30-to-60-second video.

Concept:
[insert concept]

For each shot provide:
- shot number
- purpose in the sequence
- subject description
- action
- camera framing or movement idea
- lighting intent
- environment details
- continuity notes that must stay consistent across all shots
```

## Stronger Prompt Version
Use this version when you want more structured outputs:

```text
You are a cinematic storyboard assistant helping create a short 30-to-60-second AI-generated video.

Create a 5-shot sequence from the concept below.
The sequence must feel achievable with current AI image and image-to-video workflows.

Concept:
[insert concept]

Video goal:
[product ad / brand mood piece / portfolio scene]

Audience:
[insert audience]

For each shot, return:
- shot number
- role in the sequence
- one-sentence shot description
- subject description that stays consistent across all shots
- action
- camera framing
- lighting intent
- environment details
- continuity details to preserve on Day 2

Constraints:
- keep the sequence visually coherent
- avoid impossible scene changes unless clearly motivated
- escalate toward a stronger final payoff shot
- write clearly enough that each shot can later become an image prompt
```

## Example 5-Shot Storyboard
### Example concept
"A sleek espresso machine transforms a tired morning into a premium ritual."

### Example sequence
1. **Hook** — Extreme close-up of the machine power light turning on in a dim kitchen at dawn.
2. **Context** — Medium shot of the machine on a clean stone counter with soft window light entering the frame.
3. **Detail** — Close shot of espresso pouring with steam and rich crema.
4. **Escalation** — Slow push-in on a hand lifting the finished cup while warm light catches the rising steam.
5. **Payoff** — Wide hero shot of the machine and cup in a calm premium kitchen with a polished final composition.

## Deep Dive
### Why direct text-to-video often fails
Jumping straight from one broad prompt to final motion usually reduces control.
Storyboards create a stable intermediate layer so you can lock the idea before fighting motion artifacts.

### What makes a strong shot list
A strong shot list balances:
- visual clarity
- progression of energy
- continuity of subject identity
- a believable change from first frame to last frame

### What continuity notes should include
Continuity is not just the same object name repeated five times.
Capture the attributes that must survive image generation:
- character age, wardrobe, hairstyle, and expression range
- product shape, color, material, and signature design details
- location type, time of day, and weather or atmosphere
- style adjectives such as cinematic, grounded, minimal, glossy, gritty, or dreamy

### How to think like a director instead of a prompt writer
Do not start by asking, "What words make the model do something cool?"
Start by asking, "What does the viewer need to see, in what order, to feel the intended result?"

That change in mindset creates better prompts later because the sequence already has purpose.

### Shot roles that work well in short-form video
- **Establishing shot:** sets place and mood
- **Hero shot:** presents the subject at its best
- **Detail shot:** sells texture, craft, or specificity
- **Transition shot:** creates movement between ideas
- **Payoff shot:** leaves the lasting impression

## Troubleshooting
### Problem: the idea is too big
If your concept needs ten shots to make sense, reduce the scope.
Shrink the story to one transformation, one reveal, or one emotional beat.

### Problem: every shot sounds the same
Give each shot one job only.
If two shots both "show the product nicely," merge them or make one a detail shot instead.

### Problem: the style keeps changing in your head
Write three fixed style anchors and reuse them everywhere.

Example:
- premium
- moody morning light
- clean cinematic realism

### Problem: the payoff feels weak
Ask what visual idea the entire sequence is building toward.
If the last shot is not clearly the best or clearest frame, redesign it first.

## Quality Checklist
Before moving to Day 2, confirm that your storyboard:
- uses one clear subject identity
- keeps one coherent world or aesthetic
- can be understood without extra explanation
- contains a stronger ending than opening
- gives enough detail to write image prompts without inventing the scene again

## Mini Assignment
Write two alternate versions of your fifth shot:
- one optimized for emotional impact
- one optimized for product clarity

Then choose which version better fits your actual goal.

### Common mistakes
- Too many ideas in one video
- No defined payoff shot
- Inconsistent subject description across shots
- No lighting or environment continuity

## Checkpoint
By the end of Day 1, you should be able to explain your full video in five precise shots without improvising.

## Save for Tomorrow
Carry these exact notes into Day 2:
- final subject description
- environment description
- style anchors
- each shot's framing notes
- the final approved payoff shot

## Tomorrow
Day 2 turns this storyboard into static frames with consistent visual identity.
